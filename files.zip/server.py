from fastapi import FastAPI, APIRouter, HTTPException, Depends, status, UploadFile, File
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from fastapi.responses import StreamingResponse
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import os
import logging
import httpx
import io
import base64
from pathlib import Path
from pydantic import BaseModel, Field
from typing import List, Optional, Any
import uuid
from datetime import datetime, timezone, timedelta
import jwt
from passlib.context import CryptContext
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.jobstores.mongodb import MongoDBJobStore

# ── Rembg import (fondo remover, 100% gratuito, local) ──────────────────────
try:
    from rembg import remove as rembg_remove
    REMBG_AVAILABLE = True
except ImportError:
    REMBG_AVAILABLE = False
    logging.warning("rembg no instalado. Instala con: pip install rembg")

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# ── Config ───────────────────────────────────────────────────────────────────
MONGO_URL          = os.environ.get("MONGO_URL", "mongodb://localhost:27017")
DB_NAME            = os.environ.get("DB_NAME", "reyna_moda_db")
JWT_SECRET         = os.environ.get("JWT_SECRET_KEY", "reyna_moda_secret_key_2025")
EMERGENT_LLM_KEY   = os.environ.get("EMERGENT_LLM_KEY", "")
ADMIN_DEFAULT_PASS = os.environ.get("ADMIN_DEFAULT_PASSWORD", "ReynaAdmin2025")

# ── Instagram (Meta Graph API – GRATIS) ──────────────────────────────────────
IG_ACCESS_TOKEN    = os.environ.get("IG_ACCESS_TOKEN", "")
IG_BUSINESS_ID     = os.environ.get("IG_BUSINESS_ID", "")  # Instagram Business Account ID
META_API_VERSION   = "v19.0"

# ── WhatsApp (Meta Cloud API – GRATIS hasta 1000 conv/mes) ───────────────────
WA_PHONE_NUMBER_ID = os.environ.get("WA_PHONE_NUMBER_ID", "")
WA_ACCESS_TOKEN    = os.environ.get("WA_ACCESS_TOKEN", "")  # mismo token que IG si misma app

# ── TikTok (semi-auto) ────────────────────────────────────────────────────────
TIKTOK_ACCESS_TOKEN = os.environ.get("TIKTOK_ACCESS_TOKEN", "")
ADMIN_WHATSAPP      = os.environ.get("ADMIN_WHATSAPP", "573167470857")

# ── DB & App ─────────────────────────────────────────────────────────────────
client = AsyncIOMotorClient(MONGO_URL)
db     = client[DB_NAME]

app    = FastAPI(title="REYNA MODA API")
router = APIRouter()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

pwd_ctx  = CryptContext(schemes=["bcrypt"], deprecated="auto")
security = HTTPBearer()

# ── APScheduler (publicaciones programadas – GRATIS) ─────────────────────────
scheduler = AsyncIOScheduler()

# ════════════════════════════════════════════════════════════════════════════
# MODELOS
# ════════════════════════════════════════════════════════════════════════════

class Product(BaseModel):
    name: str
    description: str
    price: float
    salePrice: Optional[float] = None
    category: str
    sizes: List[str] = []
    colors: List[str] = []
    stock: int
    images: List[str] = []
    video: Optional[str] = None
    tags: List[str] = []
    active: bool = True

class OrderItem(BaseModel):
    productId: str
    productName: str
    price: float
    quantity: int
    size: Optional[str] = None
    color: Optional[str] = None

class Order(BaseModel):
    customerName: str
    phone: str
    email: Optional[str] = None
    address: str
    city: str
    department: str
    paymentMethod: str
    items: List[OrderItem]
    subtotal: float
    shippingCost: float
    total: float
    notes: Optional[str] = None

class LoginRequest(BaseModel):
    username: str
    password: str

class StatusUpdate(BaseModel):
    status: str

# ── Social Media Models ───────────────────────────────────────────────────────

class GenerateContentRequest(BaseModel):
    productName: str
    category: str
    price: float
    salePrice: Optional[float] = None
    tags: List[str] = []
    contentType: str = "post"   # post | reel | story | promo
    tone: str = "elegant"       # elegant | fun | urgent | romantic

class SchedulePostRequest(BaseModel):
    caption: str
    hashtags: str
    imageUrl: Optional[str] = None
    platforms: List[str]        # ["instagram", "tiktok", "whatsapp"]
    scheduledAt: Optional[str] = None  # ISO string; None = publicar ahora
    productName: Optional[str] = None

class ConnectInstagramRequest(BaseModel):
    accessToken: str
    businessAccountId: str

class ConnectWhatsAppRequest(BaseModel):
    phoneNumberId: str
    accessToken: str

# ════════════════════════════════════════════════════════════════════════════
# AUTH
# ════════════════════════════════════════════════════════════════════════════

def make_token(username: str) -> str:
    exp = datetime.now(timezone.utc) + timedelta(hours=24)
    return jwt.encode({"sub": username, "exp": exp}, JWT_SECRET, algorithm="HS256")

async def get_current_admin(creds: HTTPAuthorizationCredentials = Depends(security)):
    try:
        payload = jwt.decode(creds.credentials, JWT_SECRET, algorithms=["HS256"])
        return payload["sub"]
    except Exception:
        raise HTTPException(status_code=401, detail="Token inválido")

@router.post("/auth/login")
async def login(req: LoginRequest):
    admin = await db.admins.find_one({"username": req.username})
    if not admin or not pwd_ctx.verify(req.password, admin["password"]):
        raise HTTPException(status_code=401, detail="Credenciales incorrectas")
    return {"access_token": make_token(req.username), "username": req.username}

@router.post("/auth/register")
async def register(req: LoginRequest):
    if await db.admins.find_one({"username": req.username}):
        raise HTTPException(status_code=400, detail="Usuario ya existe")
    await db.admins.insert_one({
        "username": req.username,
        "password": pwd_ctx.hash(req.password),
        "createdAt": datetime.now(timezone.utc).isoformat()
    })
    return {"message": "Admin creado"}

@router.get("/auth/me")
async def me(username: str = Depends(get_current_admin)):
    return {"username": username}

# ════════════════════════════════════════════════════════════════════════════
# PRODUCTOS
# ════════════════════════════════════════════════════════════════════════════

def serialize(doc) -> dict:
    doc["id"] = str(doc.pop("_id", ""))
    return doc

@router.get("/products")
async def list_products(category: Optional[str] = None, search: Optional[str] = None,
                        active: Optional[str] = None):
    q: dict = {}
    if category: q["category"] = category
    if active == "true": q["active"] = True
    if search: q["name"] = {"$regex": search, "$options": "i"}
    docs = await db.products.find(q).to_list(100)
    return [serialize(d) for d in docs]

@router.get("/products/{product_id}")
async def get_product(product_id: str):
    from bson import ObjectId
    doc = await db.products.find_one({"_id": ObjectId(product_id)})
    if not doc: raise HTTPException(404, "Producto no encontrado")
    return serialize(doc)

@router.post("/products")
async def create_product(p: Product, _=Depends(get_current_admin)):
    doc = p.model_dump()
    doc["createdAt"] = datetime.now(timezone.utc).isoformat()
    doc["sold"] = 0
    doc["views"] = 0
    result = await db.products.insert_one(doc)
    doc["id"] = str(result.inserted_id)
    return doc

@router.put("/products/{product_id}")
async def update_product(product_id: str, p: Product, _=Depends(get_current_admin)):
    from bson import ObjectId
    await db.products.update_one({"_id": ObjectId(product_id)}, {"$set": p.model_dump()})
    return {"message": "Actualizado"}

@router.delete("/products/{product_id}")
async def delete_product(product_id: str, _=Depends(get_current_admin)):
    from bson import ObjectId
    await db.products.delete_one({"_id": ObjectId(product_id)})
    return {"message": "Eliminado"}

# ════════════════════════════════════════════════════════════════════════════
# PEDIDOS
# ════════════════════════════════════════════════════════════════════════════

@router.post("/orders")
async def create_order(order: Order):
    doc = order.model_dump()
    doc["orderNumber"] = f"RM-{datetime.now().strftime('%Y%m%d')}-{str(uuid.uuid4())[:6].upper()}"
    doc["status"] = "nuevo"
    doc["createdAt"] = datetime.now(timezone.utc).isoformat()
    result = await db.orders.insert_one(doc)
    doc["id"] = str(result.inserted_id)
    return doc

@router.get("/orders")
async def list_orders(status: Optional[str] = None, _=Depends(get_current_admin)):
    q = {}
    if status: q["status"] = status
    docs = await db.orders.find(q).sort("createdAt", -1).to_list(200)
    return [serialize(d) for d in docs]

@router.get("/orders/{order_id}")
async def get_order(order_id: str, _=Depends(get_current_admin)):
    from bson import ObjectId
    doc = await db.orders.find_one({"_id": ObjectId(order_id)})
    if not doc: raise HTTPException(404, "Pedido no encontrado")
    return serialize(doc)

@router.put("/orders/{order_id}/status")
async def update_order_status(order_id: str, update: StatusUpdate, _=Depends(get_current_admin)):
    from bson import ObjectId
    await db.orders.update_one({"_id": ObjectId(order_id)}, {"$set": {"status": update.status}})
    return {"message": "Estado actualizado"}

# ════════════════════════════════════════════════════════════════════════════
# ANALYTICS
# ════════════════════════════════════════════════════════════════════════════

@router.get("/analytics")
async def analytics(_=Depends(get_current_admin)):
    total_products  = await db.products.count_documents({"active": True})
    total_orders    = await db.orders.count_documents({})
    pending_orders  = await db.orders.count_documents({"status": "nuevo"})
    low_stock       = await db.products.count_documents({"stock": {"$lt": 5}, "active": True})
    pipeline = [{"$group": {"_id": None, "total": {"$sum": "$total"}}}]
    revenue_result  = await db.orders.aggregate(pipeline).to_list(1)
    total_revenue   = revenue_result[0]["total"] if revenue_result else 0
    top_docs        = await db.products.find().sort("sold", -1).limit(5).to_list(5)
    return {
        "totalProducts": total_products,
        "totalOrders": total_orders,
        "pendingOrders": pending_orders,
        "lowStockProducts": low_stock,
        "totalRevenue": total_revenue,
        "topProducts": [serialize(d) for d in top_docs],
    }

# ════════════════════════════════════════════════════════════════════════════
# UTILIDADES
# ════════════════════════════════════════════════════════════════════════════

LOCAL_CITIES = {"bucaramanga", "floridablanca", "giron", "girón", "piedecuesta"}

@router.get("/shipping-cost/{city}")
async def shipping_cost(city: str):
    cost = 5000 if city.lower().strip() in LOCAL_CITIES else 15000
    return {"city": city, "shippingCost": cost}

@router.get("/health")
async def health():
    return {"status": "ok", "timestamp": datetime.now(timezone.utc).isoformat()}

# ════════════════════════════════════════════════════════════════════════════
# IA – DESCRIPCIONES Y MARKETING (usando tu Emergent LLM Key ya existente)
# ════════════════════════════════════════════════════════════════════════════

async def call_llm(system_prompt: str, user_prompt: str) -> str:
    """Llama a la API de Emergent/OpenAI con tu llave existente."""
    async with httpx.AsyncClient(timeout=30) as client_http:
        resp = await client_http.post(
            "https://api.openai.com/v1/chat/completions",
            headers={"Authorization": f"Bearer {EMERGENT_LLM_KEY}"},
            json={
                "model": "gpt-4o-mini",   # económico y suficiente
                "messages": [
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt}
                ],
                "max_tokens": 600,
                "temperature": 0.8,
            }
        )
    resp.raise_for_status()
    return resp.json()["choices"][0]["message"]["content"].strip()

BRAND_SYSTEM = """Eres el agente de marketing de REYNA MODA, una boutique premium en Floridablanca, Santander, Colombia.
Slogan: 'Para todas las mujeres que quieran lucir como reynas'.
Colores de marca: negro, dorado, fucsia.
Tono: elegante, aspiracional, empoderador, contextualizado para el mercado colombiano.
WhatsApp: 3167470857. Instagram: @reyna_moda."""

@router.post("/ai/generate-description")
async def gen_description(req: Any, _=Depends(get_current_admin)):
    body = req if isinstance(req, dict) else req.__dict__
    prompt = f"Crea una descripción de producto corta (máx 3 oraciones) para: {body.get('productName')}, categoría {body.get('category')}. Tags: {body.get('tags', [])}."
    desc = await call_llm(BRAND_SYSTEM, prompt)
    return {"description": desc}

@router.post("/ai/generate-marketing")
async def gen_marketing(req: Any, _=Depends(get_current_admin)):
    body = req if isinstance(req, dict) else req.__dict__
    prompt = f"Crea copy de marketing para redes sociales del producto '{body.get('productName')}' categoría {body.get('category')}. Incluye versión para Instagram, TikTok y WhatsApp. Tags: {body.get('tags', [])}."
    copy = await call_llm(BRAND_SYSTEM, prompt)
    return {"marketingCopy": copy}

@router.post("/chatbot")
async def chatbot(req: Any):
    body = req if isinstance(req, dict) else req.__dict__
    system = f"""{BRAND_SYSTEM}
Eres el chatbot de ventas de REYNA MODA. Responde siempre como 'mi Reyna' o 'mi Rey'.
Métodos de pago: Nequi 3167470857, Davivienda, Bancolombia (titular: Felix Abraham Villamizar), Contra entrega (área metropolitana de Bucaramanga).
Envíos: $5.000 local (Bucaramanga, Floridablanca, Girón, Piedecuesta), $15.000 nacional.
Sé breve, cálido y orientado a cerrar la venta."""
    response = await call_llm(system, body.get("message", ""))
    return {"response": response}

# ════════════════════════════════════════════════════════════════════════════
# SOCIAL MEDIA – MÓDULO NUEVO (costo $0)
# ════════════════════════════════════════════════════════════════════════════

# ── 1. Guardar credenciales OAuth en DB ──────────────────────────────────────

@router.post("/social/connect/instagram")
async def connect_instagram(req: ConnectInstagramRequest, _=Depends(get_current_admin)):
    """Guarda el access token de Instagram Business en la base de datos."""
    await db.social_config.update_one(
        {"platform": "instagram"},
        {"$set": {
            "platform": "instagram",
            "accessToken": req.accessToken,
            "businessAccountId": req.businessAccountId,
            "connectedAt": datetime.now(timezone.utc).isoformat(),
            "active": True
        }},
        upsert=True
    )
    return {"message": "Instagram conectado correctamente"}

@router.post("/social/connect/whatsapp")
async def connect_whatsapp(req: ConnectWhatsAppRequest, _=Depends(get_current_admin)):
    """Guarda el Phone Number ID de WhatsApp Cloud API."""
    await db.social_config.update_one(
        {"platform": "whatsapp"},
        {"$set": {
            "platform": "whatsapp",
            "phoneNumberId": req.phoneNumberId,
            "accessToken": req.accessToken,
            "connectedAt": datetime.now(timezone.utc).isoformat(),
            "active": True
        }},
        upsert=True
    )
    return {"message": "WhatsApp Business API conectado correctamente"}

@router.get("/social/status")
async def social_status(_=Depends(get_current_admin)):
    """Devuelve el estado de conexión de cada plataforma."""
    configs = await db.social_config.find({}).to_list(10)
    result = {}
    for c in configs:
        result[c["platform"]] = {
            "connected": c.get("active", False),
            "connectedAt": c.get("connectedAt"),
        }
    return result

# ── 2. Generar contenido para redes (IA + hashtags) ──────────────────────────

@router.post("/social/generate-content")
async def generate_social_content(req: GenerateContentRequest, _=Depends(get_current_admin)):
    """
    Genera caption + hashtags optimizados para cada red.
    Usa tu Emergent LLM Key existente – costo $0 adicional.
    """
    tone_map = {
        "elegant":  "elegante y aspiracional, empoderador",
        "fun":      "divertido, cercano y juvenil",
        "urgent":   "urgente, oferta limitada, genera FOMO",
        "romantic": "romántico, especial, para regalo",
    }
    type_map = {
        "post":  "publicación de feed de Instagram",
        "reel":  "video corto Reel / TikTok (incluye gancho inicial para los primeros 3 segundos)",
        "story": "Story de Instagram o WhatsApp (texto corto, máx 2 líneas)",
        "promo": "publicación de oferta/promoción con precio y urgencia",
    }
    price_str = f"${req.salePrice:,.0f} (antes ${req.price:,.0f})" if req.salePrice else f"${req.price:,.0f}"

    prompt = f"""Crea contenido para redes sociales de REYNA MODA.
Producto: {req.productName}
Categoría: {req.category}
Precio: {price_str} COP
Tags: {', '.join(req.tags) if req.tags else 'N/A'}
Tipo de contenido: {type_map.get(req.contentType, 'publicación')}
Tono: {tone_map.get(req.tone, 'elegante')}

Responde EXACTAMENTE en este formato:
CAPTION:
[caption aquí con emojis, máx 4 líneas]

HASHTAGS:
[20 hashtags relevantes para Colombia, moda y el producto]

TIKTOK_HOOK:
[primera línea gancho para TikTok, máx 10 palabras]"""

    raw = await call_llm(BRAND_SYSTEM, prompt)

    # Parsear la respuesta
    caption, hashtags, tiktok_hook = "", "", ""
    for section in raw.split("\n\n"):
        if section.startswith("CAPTION:"):
            caption = section.replace("CAPTION:", "").strip()
        elif section.startswith("HASHTAGS:"):
            hashtags = section.replace("HASHTAGS:", "").strip()
        elif section.startswith("TIKTOK_HOOK:"):
            tiktok_hook = section.replace("TIKTOK_HOOK:", "").strip()

    return {
        "caption": caption or raw,
        "hashtags": hashtags or "#ReynaModa #ModaColombiana #Floridablanca",
        "tiktokHook": tiktok_hook,
        "fullPost": f"{caption}\n\n{hashtags}",
    }

# ── 3. Publicar en Instagram (Meta Graph API – GRATIS) ───────────────────────

async def _get_ig_config():
    cfg = await db.social_config.find_one({"platform": "instagram", "active": True})
    if not cfg:
        raise HTTPException(400, "Instagram no está conectado. Ve a Social > Cuentas y conecta tu cuenta.")
    return cfg

@router.post("/social/publish/instagram")
async def publish_instagram(req: SchedulePostRequest, _=Depends(get_current_admin)):
    """
    Publica en Instagram Business usando Meta Graph API (GRATIS).
    Requiere imagen pública accesible por URL.
    """
    cfg = await _get_ig_config()
    token    = cfg["accessToken"]
    ig_id    = cfg["businessAccountId"]
    base_url = f"https://graph.facebook.com/{META_API_VERSION}"

    if not req.imageUrl:
        raise HTTPException(400, "Se requiere una URL de imagen para publicar en Instagram")

    caption_full = f"{req.caption}\n\n{req.hashtags}"

    async with httpx.AsyncClient(timeout=30) as h:
        # Paso 1: Crear container de media
        r1 = await h.post(f"{base_url}/{ig_id}/media", params={
            "image_url": req.imageUrl,
            "caption": caption_full,
            "access_token": token,
        })
        r1.raise_for_status()
        container_id = r1.json().get("id")

        # Paso 2: Publicar container
        r2 = await h.post(f"{base_url}/{ig_id}/media_publish", params={
            "creation_id": container_id,
            "access_token": token,
        })
        r2.raise_for_status()
        post_id = r2.json().get("id")

    # Guardar en historial
    await db.social_posts.insert_one({
        "platform": "instagram",
        "productName": req.productName,
        "caption": req.caption,
        "hashtags": req.hashtags,
        "imageUrl": req.imageUrl,
        "postId": post_id,
        "status": "published",
        "publishedAt": datetime.now(timezone.utc).isoformat(),
    })

    return {"message": "Publicado en Instagram", "postId": post_id}

# ── 4. Enviar a WhatsApp Business API (GRATIS – 1000 conv/mes) ───────────────

@router.post("/social/publish/whatsapp")
async def publish_whatsapp(req: SchedulePostRequest, _=Depends(get_current_admin)):
    """
    Envía el contenido al WhatsApp del admin para que lo publique en TikTok
    con un solo toque, O envía mensajes de catálogo a clientes.
    Usa Meta Cloud API – GRATIS hasta 1000 conversaciones/mes.
    """
    cfg = await db.social_config.find_one({"platform": "whatsapp", "active": True})

    if not cfg:
        # Fallback: generar link wa.me (flujo actual sin costo)
        text = f"*{req.productName or 'Nuevo producto'}*\n\n{req.caption}\n\n{req.hashtags}"
        wa_url = f"https://wa.me/{ADMIN_WHATSAPP}?text={httpx.QueryParams({'': text}).value}"
        return {"message": "Abre este link para enviar por WhatsApp", "url": wa_url, "method": "link"}

    # Con API oficial
    phone_id = cfg["phoneNumberId"]
    token    = cfg["accessToken"]
    message  = f"*REYNA MODA – Nuevo contenido listo para publicar*\n\n{req.caption}\n\n{req.hashtags}"
    if req.imageUrl:
        message += f"\n\nImagen: {req.imageUrl}"

    async with httpx.AsyncClient(timeout=20) as h:
        resp = await h.post(
            f"https://graph.facebook.com/{META_API_VERSION}/{phone_id}/messages",
            headers={"Authorization": f"Bearer {token}"},
            json={
                "messaging_product": "whatsapp",
                "to": ADMIN_WHATSAPP,
                "type": "text",
                "text": {"body": message}
            }
        )
        resp.raise_for_status()

    await db.social_posts.insert_one({
        "platform": "whatsapp",
        "productName": req.productName,
        "caption": req.caption,
        "status": "sent",
        "publishedAt": datetime.now(timezone.utc).isoformat(),
    })

    return {"message": "Contenido enviado a WhatsApp del admin", "method": "api"}

# ── 5. TikTok – flujo semi-automático (gratis, sin aprobación) ───────────────

@router.post("/social/prepare/tiktok")
async def prepare_tiktok(req: SchedulePostRequest, _=Depends(get_current_admin)):
    """
    Prepara el contenido para TikTok y lo envía al WhatsApp del admin.
    El admin lo publica con un toque desde el celular.
    Costo: $0 – no requiere aprobación de TikTok.
    """
    tiktok_text = f"""🎬 *CONTENIDO PARA TIKTOK – REYNA MODA*

📌 Caption:
{req.caption}

#️⃣ Hashtags:
{req.hashtags}

📸 Imagen/Video:
{req.imageUrl or 'Adjunta tu imagen aquí'}

👉 Pasos:
1. Descarga la imagen
2. Abre TikTok → Crear → Foto
3. Pega el caption y hashtags
4. Publica 👑"""

    # Enviar vía wa.me (siempre disponible, $0)
    import urllib.parse
    wa_url = f"https://wa.me/{ADMIN_WHATSAPP}?text={urllib.parse.quote(tiktok_text)}"

    # Si tiene API oficial, enviar también por ahí
    cfg = await db.social_config.find_one({"platform": "whatsapp", "active": True})
    api_sent = False
    if cfg:
        try:
            async with httpx.AsyncClient(timeout=20) as h:
                await h.post(
                    f"https://graph.facebook.com/{META_API_VERSION}/{cfg['phoneNumberId']}/messages",
                    headers={"Authorization": f"Bearer {cfg['accessToken']}"},
                    json={
                        "messaging_product": "whatsapp",
                        "to": ADMIN_WHATSAPP,
                        "type": "text",
                        "text": {"body": tiktok_text}
                    }
                )
            api_sent = True
        except Exception:
            pass

    await db.social_posts.insert_one({
        "platform": "tiktok",
        "productName": req.productName,
        "caption": req.caption,
        "status": "pending_manual",
        "preparedAt": datetime.now(timezone.utc).isoformat(),
    })

    return {
        "message": "Contenido preparado para TikTok",
        "waUrl": wa_url,
        "apiSent": api_sent,
    }

# ── 6. Programar publicación futura (APScheduler + MongoDB – GRATIS) ─────────

@router.post("/social/schedule")
async def schedule_post(req: SchedulePostRequest, _=Depends(get_current_admin)):
    """
    Programa una publicación para fecha/hora futura.
    Usa APScheduler con jobstore en MongoDB – 100% gratuito.
    """
    if not req.scheduledAt:
        # Publicar inmediatamente en todas las plataformas seleccionadas
        results = {}
        for platform in req.platforms:
            if platform == "instagram":
                results["instagram"] = (await publish_instagram(req)).get("message")
            elif platform == "whatsapp":
                results["whatsapp"] = (await publish_whatsapp(req)).get("message")
            elif platform == "tiktok":
                results["tiktok"] = (await prepare_tiktok(req)).get("message")
        return {"message": "Publicado inmediatamente", "results": results}

    scheduled_time = datetime.fromisoformat(req.scheduledAt)
    job_id = f"post_{uuid.uuid4().hex[:8]}"

    # Guardar en DB para el scheduler
    await db.scheduled_posts.insert_one({
        "jobId": job_id,
        "platforms": req.platforms,
        "caption": req.caption,
        "hashtags": req.hashtags,
        "imageUrl": req.imageUrl,
        "productName": req.productName,
        "scheduledAt": req.scheduledAt,
        "status": "scheduled",
        "createdAt": datetime.now(timezone.utc).isoformat(),
    })

    return {
        "message": f"Publicación programada para {req.scheduledAt}",
        "jobId": job_id,
    }

@router.get("/social/scheduled")
async def list_scheduled(_=Depends(get_current_admin)):
    docs = await db.scheduled_posts.find({"status": "scheduled"}).to_list(50)
    return [serialize(d) for d in docs]

@router.get("/social/history")
async def social_history(_=Depends(get_current_admin)):
    docs = await db.social_posts.find({}).sort("publishedAt", -1).limit(50).to_list(50)
    return [serialize(d) for d in docs]

@router.get("/social/stats")
async def social_stats(_=Depends(get_current_admin)):
    total     = await db.social_posts.count_documents({})
    published = await db.social_posts.count_documents({"status": "published"})
    scheduled = await db.scheduled_posts.count_documents({"status": "scheduled"})
    return {"totalPosts": total, "published": published, "scheduled": scheduled}

# ── 7. Remover fondo con rembg (GRATIS, corre en tu servidor) ────────────────

@router.post("/social/remove-background")
async def remove_background(file: UploadFile = File(...), _=Depends(get_current_admin)):
    """
    Elimina el fondo de una imagen con rembg (open source, gratis).
    Instalar: pip install rembg
    """
    if not REMBG_AVAILABLE:
        raise HTTPException(501, "rembg no está instalado. Ejecuta: pip install rembg")

    content = await file.read()
    output  = rembg_remove(content)

    # Devolver como PNG con fondo transparente
    return StreamingResponse(
        io.BytesIO(output),
        media_type="image/png",
        headers={"Content-Disposition": f"attachment; filename=nobg_{file.filename}"}
    )

@router.post("/social/remove-background-url")
async def remove_background_url(body: dict, _=Depends(get_current_admin)):
    """Versión para URL pública de imagen."""
    if not REMBG_AVAILABLE:
        raise HTTPException(501, "rembg no instalado")
    async with httpx.AsyncClient(timeout=30) as h:
        resp = await h.get(body["imageUrl"])
        resp.raise_for_status()
    output = rembg_remove(resp.content)
    b64    = base64.b64encode(output).decode()
    return {"imageBase64": f"data:image/png;base64,{b64}"}

# ── 8. Confirmación de pedido por WhatsApp API (sin costo si cliente escribe primero) ─

@router.post("/orders/{order_id}/notify-whatsapp")
async def notify_order_whatsapp(order_id: str, _=Depends(get_current_admin)):
    """
    Envía confirmación de pedido al cliente por WhatsApp.
    Si el cliente escribió primero (ventana 24h): GRATIS.
    Si no: ~$0.0008 USD por mensaje de utilidad.
    """
    from bson import ObjectId
    order = await db.orders.find_one({"_id": ObjectId(order_id)})
    if not order: raise HTTPException(404, "Pedido no encontrado")

    cfg = await db.social_config.find_one({"platform": "whatsapp", "active": True})

    items_text = "\n".join([
        f"• {i['productName']} x{i['quantity']} — ${i['price'] * i['quantity']:,.0f}"
        for i in order["items"]
    ])

    message = (
        f"👑 *REYNA MODA – Pedido Confirmado*\n\n"
        f"Hola {order['customerName']}! Tu pedido está confirmado.\n\n"
        f"*Número:* {order['orderNumber']}\n"
        f"*Productos:*\n{items_text}\n\n"
        f"*Total:* ${order['total']:,.0f} COP\n"
        f"*Método de pago:* {order['paymentMethod']}\n\n"
        f"Te contactaremos pronto para coordinar el envío 💎"
    )

    if not cfg:
        # Fallback wa.me
        import urllib.parse
        wa_url = f"https://wa.me/{order['phone']}?text={urllib.parse.quote(message)}"
        return {"method": "link", "waUrl": wa_url}

    async with httpx.AsyncClient(timeout=20) as h:
        phone = order["phone"].replace("+", "").replace(" ", "")
        if not phone.startswith("57"): phone = f"57{phone}"
        resp = await h.post(
            f"https://graph.facebook.com/{META_API_VERSION}/{cfg['phoneNumberId']}/messages",
            headers={"Authorization": f"Bearer {cfg['accessToken']}"},
            json={
                "messaging_product": "whatsapp",
                "to": phone,
                "type": "text",
                "text": {"body": message}
            }
        )
        resp.raise_for_status()

    return {"method": "api", "message": "Notificación enviada al cliente"}

# ════════════════════════════════════════════════════════════════════════════
# STARTUP – crear admin por defecto + scheduler
# ════════════════════════════════════════════════════════════════════════════

@app.on_event("startup")
async def startup():
    # Admin por defecto
    if not await db.admins.find_one({"username": "admin"}):
        await db.admins.insert_one({
            "username": "admin",
            "password": pwd_ctx.hash(ADMIN_DEFAULT_PASS),
            "createdAt": datetime.now(timezone.utc).isoformat()
        })
        logger.info("Admin por defecto creado")

    # Índices útiles
    await db.products.create_index("category")
    await db.orders.create_index("status")
    await db.social_posts.create_index("publishedAt")

    # Scheduler para publicaciones programadas
    scheduler.start()
    logger.info("APScheduler iniciado")

    # Job que revisa publicaciones pendientes cada minuto
    scheduler.add_job(
        check_scheduled_posts,
        "interval",
        minutes=1,
        id="check_posts",
        replace_existing=True
    )

async def check_scheduled_posts():
    """Ejecuta publicaciones programadas cuando llega su hora."""
    now = datetime.now(timezone.utc)
    pending = await db.scheduled_posts.find({"status": "scheduled"}).to_list(20)
    for post in pending:
        scheduled = datetime.fromisoformat(post["scheduledAt"])
        if scheduled.tzinfo is None:
            scheduled = scheduled.replace(tzinfo=timezone.utc)
        if now >= scheduled:
            req = SchedulePostRequest(
                caption=post["caption"],
                hashtags=post["hashtags"],
                imageUrl=post.get("imageUrl"),
                platforms=post["platforms"],
                productName=post.get("productName"),
            )
            try:
                for platform in post["platforms"]:
                    if platform == "instagram":
                        await publish_instagram(req)
                    elif platform == "whatsapp":
                        await publish_whatsapp(req)
                    elif platform == "tiktok":
                        await prepare_tiktok(req)
                from bson import ObjectId
                await db.scheduled_posts.update_one(
                    {"_id": post["_id"]},
                    {"$set": {"status": "published", "publishedAt": now.isoformat()}}
                )
                logger.info(f"Post programado publicado: {post['_id']}")
            except Exception as e:
                logger.error(f"Error publicando post programado: {e}")

@app.on_event("shutdown")
async def shutdown():
    scheduler.shutdown()

# ════════════════════════════════════════════════════════════════════════════
app.include_router(router, prefix="/api")
# ════════════════════════════════════════════════════════════════════════════
